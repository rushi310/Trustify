import React from 'react'
import Footer from '../Pages/Footer/Footer'
import Hero from './Herosec/Hero'
import './Home.css'
import HomeContent from './HomeContent/HomeContent'
import Temp from './HomeContent/Templets/Temp/Temp'
const Home = () => {
  return (
    <div className='Home'>
      <Hero />
      <HomeContent />
      <Temp/>
      <Footer />
    </div>
  )
}

export default Home

