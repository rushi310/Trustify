import React from 'react'
import {HiArrowNarrowDown} from 'react-icons/hi'
import heroimg from './Ele1.png';
const Hero = () => {
    return (
        <>

            <div className='Hero'>
            
                <div className='Heroimg'>
                    <img  src={heroimg}/>
                </div>
                
                <div className='HeroText'>
                    <h1 className='titleh1'>
                        Let's Verify
                    </h1>
                    <h2 className='titleh2'>
                        Verify your document in
                    </h2>
                    <h2 className='titleh2'>
                        just one step
                    </h2>
                </div>

            </div>
        </>
    )
}

export default Hero