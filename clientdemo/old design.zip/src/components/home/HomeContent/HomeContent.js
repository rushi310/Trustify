import React from 'react'
import { MdQrCodeScanner } from 'react-icons/md'
import { BsSearch } from 'react-icons/bs'
import Tempnav from './Templets/Temp_nav/Tempnav'
import Temp from './Templets/Temp/Temp'
import { Link } from 'react-router-dom'
const HomeContent = () => {
    return (
        <div>
            <div className='Homecontent'>
                <h1 className='hometext1'>Directly search for ID</h1>

                <form onsubmit="event.preventDefault();" role="search">
                    <input id="search" type="search" placeholder="Search..." autofocus required />
                    <button id='searchbtn' type="submit"><span id='searchbtnicon'><BsSearch /></span></button>
                </form>
                <br />

                <hr />
                <Link to="/qronly" className='QRLINK'><MdQrCodeScanner /> Generate QR only</Link>
                <br />
                <div>
                    <Tempnav />
                </div>
            </div>
        </div>
    )
}

export default HomeContent