import { Link } from 'react-router-dom'
import './Tempnav.css';
import { GrCertificate } from 'react-icons/gr';
import { GrDocumentText } from "react-icons/gr";
import { SlEnvolopeLetter } from "react-icons/sl";
import { MdDevicesOther } from "react-icons/md";
import { RiCheckboxMultipleBlankLine } from "react-icons/ri";


export default function Tempnav() {
    return (
        <nav className="tempnav">

            <ul className='templink_name'>
                <li>
                    <div className='linkiconbg1'>
                    <RiCheckboxMultipleBlankLine className='linkicon1'/></div>
                    <Link to="/blank" className='linktext'>Blank</Link>
                </li>

                <li>
                <div className='linkiconbg2'>
                    <GrCertificate className='linkicon2'/></div>
                    <Link to="/certificate" className='linktext'>Certificate</Link>
                </li>

                <li>
                <div className='linkiconbg3'>
                    <GrDocumentText className='linkicon3'/></div>
                    <Link to="/document" className='linktext'>Document</Link>
                </li>
                <li>
                <div className='linkiconbg4'>
                    <SlEnvolopeLetter className='linkicon4'/></div>
                    <Link to="/letters" className='linktext'>Letters</Link>
                </li>
                <li>
                <div className='linkiconbg5'>
                    <MdDevicesOther className='linkicon5'/></div>
                    <Link to="/others" className='linktext'>Others</Link>
                </li>
            </ul>
        </nav>
    )
}