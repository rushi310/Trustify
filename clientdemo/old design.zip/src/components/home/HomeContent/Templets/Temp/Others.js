import React from 'react'

const Others = () => {
  return (
    <>
      
    </>
  )
}

export default Others