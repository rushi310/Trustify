import React from 'react'

const Blank = () => {
  return (
    <>
      <h1>hiii</h1>
    </>
  )
}

export default Blank