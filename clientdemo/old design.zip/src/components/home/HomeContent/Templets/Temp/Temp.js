import React from 'react'
import './Temp.css';
import Card from 'react-bootstrap/Card';
import certi1 from './certi1.png';
import certi2 from './certi2.png';
import certi3 from './certi3.webp';
import certi4 from './certi4.jpg';
import certi5 from './certi5.png';
import certi6 from './certi6.jpg';
import certi7 from './certi7.jpg';
import certi8 from './certi8.webp';
import { Link } from 'react-router-dom';
import Design1 from '../TempDesigns/Design1';

const Temp = () => {
    return (
        <>
            <div className='tempbg'>
                <Card className='tempcard'>
                    <Card.Header>Achievement Certificate1</Card.Header>
                    <Card.Body>
                        <Link to="/design1"><Card.Img className='tempimg' src={certi1} /></Link>
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Achievement Certificate2</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi2} />
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Participation Certificate1</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi3} />
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Achievement Certificate3</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi4} />
                    </Card.Body>
                </Card>
            </div>


            <div className='tempbg'>
                <Card className='tempcard'>
                    <Card.Header>Sports Certificate 1</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi5} />
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Sports Certificate 2</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi6} />
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Sports Certificate 3</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi7} />
                    </Card.Body>
                </Card>

                <Card className='tempcard'>
                    <Card.Header>Sports Certificate 4</Card.Header>
                    <Card.Body>
                        <Card.Img className='tempimg' src={certi8} />
                    </Card.Body>
                </Card>
            </div>
        </>
    )
}

export default Temp