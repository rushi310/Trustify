import React from 'react'
import Loginform from './Loginform'
const Loginpage = () => {
    return (
        <div className='login'>
            <Loginform />
        </div>
    )
}

export default Loginpage