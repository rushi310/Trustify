import React from 'react'
import { useState } from 'react';
// import {useHistory} from 'react-router-dom'
import Card from 'react-bootstrap/Card';
import Form from 'react-bootstrap/Form';
import { TbArrowNarrowRight } from 'react-icons/tb'
import { MdSupervisorAccount } from 'react-icons/md'
import { Si1Password } from 'react-icons/si'
import { Link } from 'react-router-dom'


const Signupform = () => {

    const [user, setUser] = useState({
        fname: "", lname: "", email: "", password: "", cpassword: ""
    });
    let fname, value;
    const handelInputs = (e) => {
        console.log(e)
        fname = e.target.fname;
        value = e.target.value;

        setUser({ ...user, [fname]: value });
    }

    return (
        <div>
            <div className='loginPage'>
                <Card className='Card' style={{ width: '33rem' }}>
                    <Card.Body>
                        <Form>
                            <div className="wrapper">
                                <div className="inner-warpper text-center">
                                    <h2 className="title1"><b>Welcome to Trustify</b></h2><br />
                                    <h5 className="title2">Please enter your correct details to avoid future problems</h5>
                                    <form action="" id="formvalidate">
                                        <div className="input-group inputgroup" style={{ display: 'flex', gap: '1rem' }}>
                                            <input className="form-control input2" name="userName" id="userName" type="text" value={user.fname} onChange={handelInputs} placeholder=" First Name " />
                                            <input className="form-control input2" name="userName" id="userName" type="text" value={user.lname} onChange={handelInputs} placeholder=" Last Name " />
                                        </div>
                                        <div className="input-group inputgroup">
                                            <input className="form-control input2" name="userName" id="userName" type="text" value={user.email} onChange={handelInputs} placeholder=" Email " />
                                        </div>
                                        <div className="input-group inputgroup">
                                            <input className="form-control input2" name="userPassword" id="userPassword" type="password" value={user.password} onChange={handelInputs} placeholder=" Password" />
                                        </div>
                                        <div className="input-group inputgroup">
                                            <input className="form-control input2" name="confirmuserPassword" id="confirmuserPassword" type="password" value={user.cpassword} onChange={handelInputs} placeholder="Confirm Password" />
                                        </div>

                                        <div>
                                            <button type="submit" id="login"> SignUp <span className='loginlogo'><TbArrowNarrowRight /></span></button>
                                            <br />
                                        </div><br />
                                    </form>
                                </div>
                                <hr className='hr' />
                                <div className="signup-wrapper text-center">
                                    <a className='newwaccount' href="#">Already a user? <Link to="/login"> <span className="text-primary"><MdSupervisorAccount />Back to login</span></Link></a>
                                </div>
                            </div>
                        </Form>

                    </Card.Body>
                </Card>
            </div>
        </div>
    )
}

export default Signupform