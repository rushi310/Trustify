import React from 'react'
import './LoginSignup.css'
import { Link } from 'react-router-dom'
import Card from 'react-bootstrap/Card';
import Form from 'react-bootstrap/Form';
import { TbArrowNarrowRight } from 'react-icons/tb'
import {MdSupervisorAccount} from 'react-icons/md'
import {Si1Password} from 'react-icons/si'

const Loginform = () => {
    return (
        <div className='loginPage'>
            <Card className='Card' style={{ width: '27rem' }}>
                <Card.Body>
                    <Form >
                        <div className="wrapper">
                            <div className="inner-warpper text-center">
                                <h2 className="title1"><b>Welcome back!</b></h2>
                                <h5 className="title2">Please enter your email and password</h5>
                                <form action="" id="formvalidate">
                                    <div className="input-group inputgroup">
                                        <input className="form-control input2" name="userName" id="userName" type="text" placeholder=" Email " />
                                    </div>
                                    <div className="input-group inputgroup">
                                        <input className="form-control input2" name="userPassword" id="userPassword" type="password" placeholder=" Password" />
                                    </div>
                                    <div>
                                        <button type="submit" id="login">Login... <span className='loginlogo'><TbArrowNarrowRight /></span></button>
                                        <a className="forgot pull-right"><span className='forgetlogo'><Si1Password /></span>Forgot Password?</a>
                                    </div><br/>
                                    <div className="clearfix supporter">
                                        <div className="pull-left remember-me">
                                            <input id="rememberMe" type="checkbox" />
                                            <label for="rememberMe" className='remembertext'>Remember Me</label>
                                        </div>

                                    </div>
                                </form>
                            </div>
                            <hr className='hr'/>
                            <div className="signup-wrapper text-center">
                                <a className='newwaccount' href="#">Don't have an account? <Link to="/signup"><span className="text-primary"><MdSupervisorAccount />Create One</span></Link></a>
                            </div>
                        </div>
                    </Form>

                </Card.Body>
            </Card>
        </div>
    )
}

export default Loginform