import React from 'react'
import './LoginSignup.css'
import './LoginSignup.css'
import Signupform from './Signupform';
const Signup = () => {
    return (
        <div >
            <Signupform />
        </div>
    )
}

export default Signup