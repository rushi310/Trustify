import React from 'react'

const Setting = () => {
  return (
    <div><div className='Help'>Setting</div></div>
  )
}

export default Setting