import React from 'react'
import './Help.css'
import Footer from '../Footer/Footer'

const Help = () => {
  return (
    <div>
      <div className='Help'>Help Center</div>
      <Footer />
    </div>
  )
}

export default Help