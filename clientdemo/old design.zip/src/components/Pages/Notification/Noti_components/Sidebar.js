import React from 'react'

import {BsCardChecklist} from 'react-icons/bs'
import {IoMdDoneAll} from 'react-icons/io'


const Sidebar = () => {
    return (
        <>
            <div class="dark  main" >
                <div className='title_noti'>
                    Notifications
                </div>

                <hr />

                <div className='todo'>
                    To do <BsCardChecklist />
                </div>
                <div className='complate'>
                    Completed <IoMdDoneAll />
                </div>

                <div className='read'>
                Mark all as read
                </div>
                
            </div>
        </>
    )
}

export default Sidebar