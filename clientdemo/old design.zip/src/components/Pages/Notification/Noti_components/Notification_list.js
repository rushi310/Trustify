import React from 'react'
import { BsSearch } from 'react-icons/bs'
import Noti_card from './noti_card/Noti_card'
const Notification_list = () => {
    return (
        <div>
            <div class="main2" >
                
                    <div class="box">
                        <form name="search">
                            <input type="text" class="input" name="txt" onmouseout="this.value = ''; this.blur();"/>
                        </form>
                        <i>
                        <BsSearch />
                        </i>
                        <div className='search'>
                            Search
                        </div>
                    </div>
                <hr />

                <div>
                    <Noti_card />
                </div>

            </div>

        </div>
    )
}

export default Notification_list