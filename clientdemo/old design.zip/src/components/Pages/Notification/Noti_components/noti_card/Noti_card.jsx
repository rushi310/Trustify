import React from 'react'
import { AiOutlineDelete } from 'react-icons/ai'
import profile1 from './profile1.png';
import profile2 from './profile2.png';
import profile3 from './profile3.png';
import profile4 from './profile4.png';


const Noti_card = () => {
    return (
        <>
            <div className='noti_card '>
                <div className='card_1line'>
                    <div className='profile_pic'><img src={profile1} alt="Logo" /></div>
                    <div className='name_card'><b> Rupak Ghadiya</b></div>
                    <div className='date_card'> "16/10/2022" </div>
                    <div className='delet_card'><AiOutlineDelete /></div>
                </div>
                <div className='message_card1'>
                    <p>Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.</p>
                </div>
            </div>





            <div className='noti_card2'>
                <div className='card_1line'>
                    <div className='profile_pic'><img src={profile3} alt="Logo" /></div>
                    <div className='name_card'><b> Yashi Pandey</b></div>
                    <div className='date_card'> "16/10/2022" </div>
                    <div className='delet_card'><AiOutlineDelete /></div>
                </div>
                <div className='message_card2'>
                    <p>Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.</p>
                </div>
            </div>






            <div className='noti_card3'>
                <div className='card_1line'>
                    <div className='profile_pic'><img src={profile4} alt="Logo" /></div>
                    <div className='name_card'><b> Vaidehi Devi</b></div>
                    <div className='date_card'> "16/10/2022" </div>
                    <div className='delet_card'><AiOutlineDelete /></div>
                </div>
                <div className='message_card3'>
                    <p>Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.  Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.</p>
                </div>
            </div>






            <div className='noti_card'>
                <div className='card_1line'>
                    <div className='profile_pic'><img src={profile2} alt="Logo" /></div>
                    <div className='name_card'><b> Rushikesh Bhujbal</b></div>
                    <div className='date_card'> "16/10/2022" </div>
                    <div className='delet_card'><AiOutlineDelete /></div>
                </div>
                <div className='message_card4'>
                    <p>Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.</p>
                </div>
            </div>



        </>
    )
}

export default Noti_card