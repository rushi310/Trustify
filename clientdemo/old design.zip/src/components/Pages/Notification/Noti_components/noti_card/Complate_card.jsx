import React from 'react'
import { AiOutlineDelete } from 'react-icons/ai'
import profile1 from './profile1.png';
import profile2 from './profile2.png';
import profile3 from './profile3.png';
import profile4 from './profile4.png';


const Complate_card = () => {
    return (
        <>
            <div className='noti_card '>
                <div className='card_1line'>
                    <div className='profile_pic'><img src={profile1} alt="Logo" /></div>
                    <div className='name_card'> Rupak Ghadiya</div>
                    <div className='date_card'> "16/10/2022" </div>
                    <div className='delet_card'><AiOutlineDelete /></div>
                </div>
                <div className='message_card'>
                    <p>Nostrud eu est pariatur occaecat. Pariatur minim deserunt elit est ad dolore. Excepteur Lorem incididunt aliquip ea Lorem esse nulla dolore non irure nisi esse anim sunt. Officia elit voluptate aute qui fugiat laboris adipisicing eu minim. Anim id sunt mollit magna tempor laboris magna ex elit et.</p>
                </div>
            </div>
        </>
    )
}

export default Complate_card