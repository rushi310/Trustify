import React from 'react'
import './Notification.css'
import { Route, Routes } from "react-router-dom"
import {BsCardChecklist} from 'react-icons/bs'
import {IoMdDoneAll} from 'react-icons/io'
import Sidebar from './Noti_components/Sidebar'
import Notification_list from './Noti_components/Notification_list'
import Noti_card from './Noti_components/noti_card/Noti_card'
import Complate_card from './Noti_components/noti_card/Complate_card'


const Notification = () => {
    return (
        <div className='main_div_noti'>
            <Sidebar />
            <Notification_list />
        </div >
    )
}

export default Notification