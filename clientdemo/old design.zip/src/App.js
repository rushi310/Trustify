import React from 'react'
import Nav from './components/home/Nav/Nav'
import { Route, Routes } from "react-router-dom"
import Home from './components/home/Home'
import Help from './components/Pages/Help/Help'
import Contact from './components/Pages/Contactus/Contact'
import Notification from './components/Pages/Notification/Notification'
import Setting from './components/Pages/Setting/Setting'
import Profile from './components/Pages/Profile/Profile'
import Loginpage from './components/Pages/LoginSignup/Loginpage'
import Signup from './components/Pages/LoginSignup/Signup'
import Qronly from './components/home/HomeContent/Qronly/Qronly'
import Design1 from './components/home/HomeContent/Templets/TempDesigns/Design1'

const App = () => {
  return (
    <>
      <Nav />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/home' element={<Home />} />
        <Route path='/help' element={<Help />} />
        <Route path='/contactus' element={<Contact />} />
        <Route path='/notification' element={<Notification />} />
        <Route path='/setting' element={<Setting />} />
        <Route path='/profile' element={<Profile />} />
        <Route path='/login' element={<Loginpage />} />
        <Route path='/signup' element={<Signup />} />
        <Route path='/qronly' element={<Qronly />} />
        
        
        <Route path='/design1' element={<Design1 />} />

        
      </Routes>
    </>
  )
}

export default App